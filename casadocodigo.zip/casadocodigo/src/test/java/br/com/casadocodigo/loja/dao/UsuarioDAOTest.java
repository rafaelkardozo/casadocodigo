package br.com.casadocodigo.loja.dao;

import br.com.casadocodigo.loja.models.Usuario;

public class UsuarioDAOTest {
	
	public static void main(String[] args) {
		UsuarioDAO usuarioDao = new UsuarioDAO();
		String email = "admin@casadocodigo.com.br";
		Usuario usuario = usuarioDao.loadUserByUsername(email);
		
		System.out.println(usuario.getEmail());
		
		
	}

}
